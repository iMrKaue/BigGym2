document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('nav ul li a');
    const sections = document.querySelectorAll('main section');

    // Alternar entre seções
    links.forEach((link, index) => {
        link.addEventListener('click', (e) => {
            e.preventDefault();

            // Esconder todas as seções
            sections.forEach(section => section.style.display = 'none');

            // Mostrar a seção correspondente
            sections[index].style.display = 'block';
        });
    });

    // Mostrar a primeira seção por padrão
    sections[0].style.display = 'block';
});
