async function loginProfessor(event) {
    event.preventDefault(); // Evita o reload da página

    const email = document.getElementById('login-email').value.trim();
    const senha = document.getElementById('login-senha').value.trim();

    try {
        const response = await fetch('http://localhost:3306/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, senha }),
        });

        const result = await response.json();

        if (response.status === 200) {
            alert('Login bem-sucedido!');
            window.location.href = 'administrativo.html'; // Redireciona para o painel
        } else {
            alert(result.message); // Mostra a mensagem de erro
        }
    } catch (error) {
        console.error('Erro ao realizar login:', error);
        alert('Erro no servidor. Tente novamente mais tarde.');
    }
}

document.getElementById('login-form').addEventListener('submit', loginProfessor);
