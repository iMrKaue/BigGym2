const mysql = require('mysql2');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Cristiane@87',
    database: 'BigGym'
});

module.exports = pool.promise();
