const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('./db'); // Conexão com o banco de dados

const app = express();

// Middleware para processar JSON no corpo das requisições
app.use(express.json());

// Servir arquivos estáticos (CSS, JS, Imagens)
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/images', express.static(path.join(__dirname, 'images')));

// Rota para a página inicial (index.html)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html')); // Serve o index.html
});

// Rota para login de funcionários e clientes
app.post('/views/login', async (req, res) => {
    const { email, senha } = req.body;

    try {
        // Verificar se o funcionário existe
        const [user] = await db.execute('SELECT * FROM admins WHERE email = ?', [email]);

        // Se não encontrar na tabela de administradores, procura na tabela de clientes
        if (user.length === 0) {
            const [client] = await db.execute('SELECT * FROM usuarios WHERE email = ?', [email]);
            if (client.length === 0) {
                return res.status(401).json({ error: 'Usuário não encontrado!' });
            }

            // Se for um cliente, comparar a senha
            const senhaValidaCliente = await bcrypt.compare(senha, client[0].senha);
            if (!senhaValidaCliente) {
                return res.status(401).json({ error: 'Senha incorreta!' });
            }

            // Se for um cliente, redireciona para a página do cliente
            return res.status(200).json({ message: 'Login bem-sucedido! Bem-vindo, Cliente.', tipo: 'cliente' });
        }

        // Se for funcionário, comparar a senha
        const senhaValidaFuncionario = await bcrypt.compare(senha, user[0].senha);
        if (!senhaValidaFuncionario) {
            return res.status(401).json({ error: 'Senha incorreta!' });
        }

        // Se for funcionário, redireciona para a página de administração
        return res.status(200).json({ message: 'Login bem-sucedido! Bem-vindo, Administrador.', tipo: 'funcionario' });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Rota para a página do administrador (somente acessível após login)
app.get('/views/administracao', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'administracao.html')); // Serve a página admin.html
});

// Rota para a página do cliente (somente acessível após login)
app.get('/cliente', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'cliente.html')); // Serve a página cliente.html
});

// Iniciar o servidor
app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000'));
